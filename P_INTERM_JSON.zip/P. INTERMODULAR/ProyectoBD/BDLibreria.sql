drop database if exists BDLibreria;

create database BDLibreria character set utf8mb4 collate utf8mb4_unicode_ci;

use BDLibreria;

create table autor(
	idautor INT primary key,
	nacionalidad VARCHAR(30),
	premios VARCHAR(35),
	nombre VARCHAR(35),
	apellido1 VARCHAR(35),
	apellido2 VARCHAR(35)
);

create table editorial(
	id_editorial INT primary key,
	nombre VARCHAR(35) not null,
	direccion VARCHAR(50),
	telefono VARCHAR(15) not null
);

create table premios_autor(
	premio VARCHAR(40),
	autor INT,
	primary key(premio, autor),
	constraint PK_premios_autor foreign key (autor) references AUTOR(idautor) on delete no action on update cascade
);

create table LIBRO(
	codLibro INT primary key,
	titulo VARCHAR(35) not null,
	idioma VARCHAR(35),
	fpublicacion DATE not null,
	editorial INT,
	autor INT,
	esAudiolibro BOOLEAN,
	esDigital BOOLEAN,
	esFisico BOOLEAN,
	constraint fk_libro_editorial foreign key (editorial) references EDITORIAL(id_editorial) on delete no action on update cascade,
	constraint fk_libro_autor foreign key (autor) references AUTOR(idautor) on delete no action on update cascade
);

create table libr_audiolibro(
	codLibro INT,
	ISBN VARCHAR(15),
	duracion INT,
	primary key (codLibro, ISBN),
	constraint fk_audiolibro__libro foreign key (codLibro) references LIBRO(codLibro) on delete no action on update cascade
);

create table libr_digital(
	codLibro INT,
	ISBN VARCHAR(15),
	tamano_archivo NUMERIC(5,2),
	primary key (codLibro, ISBN),
	constraint fk_digital_libro foreign key (codLibro) references LIBRO (codLibro) on delete no action on update cascade
);

create table libr_fisico(
	codLibro INT,
	ISBN VARCHAR(15),
	numpaginas INT,
	primary key (codLibro, ISBN),
	constraint fk_fisico_libro foreign key (codLibro) references LIBRO (codLibro) on delete no action on update cascade
);

create table ejemplar(
	codLibro INT,
	ISBN VARCHAR(15),
	id INT,
	estado VARCHAR(30) not null,
	primary key (codLibro, ISBN, id),
	constraint fk_ejemplar_fisico foreign key (codLibro, ISBN) references libr_fisico(codLibro, ISBN) on delete no action on update cascade
);

create table usuario(
	id INT primary key,
	nombre VARCHAR(35) not null,
	direccion VARCHAR(35),
	telefono VARCHAR(15) not null,
	email VARCHAR(35),
	fregistro DATE not null
);

create table empleado(
	id INT primary key,
	nombre VARCHAR(35) not null,
	cargo VARCHAR(40),
	fcontratacion DATE not null
);

create table prestamo(
	id INT primary key,
	fprestamo date not null,
	fdevolucion date not null,
	estado enum('Activo', 'Vencido', 'Devuelto', 'Reservado') not null,
	dias_atraso INT generated always as (datediff(fdevolucion, fprestamo)) stored,
	usuario INT,
	empleado INT,
	constraint fk_prestamo_usuario foreign key (usuario) references usuario(id) on delete no action on update cascade,
	constraint fk_prestamo_empleado foreign key (empleado) references empleado(id) on delete no action on update cascade
);

create table libro_prestamo(
	codLibro INT,
	idPrestamo INT,
	primary key (codLibro, idPrestamo),
	constraint fk_libroprestamo_libro foreign key (codLibro) references libro(codLibro) on delete no action on update cascade,
	constraint fk_libroprestamo_prestamo foreign key (idPrestamo) references prestamo(id) on delete no action on update cascade
);