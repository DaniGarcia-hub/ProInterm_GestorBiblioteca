use bdlibreria;

INSERT INTO autor VALUES 
(1, 'Española', 'Premio Planeta', 'Carlos', 'Ruiz', 'Zafón'),
(2, 'Colombiana', 'Premio Nobel', 'Gabriel', 'García', 'Márquez'),
(3, 'Japonesa', 'Premio Akutagawa', 'Haruki', 'Murakami', ''),
(4, 'Estadounidense', 'Pulitzer Prize', 'Ernest', 'Hemingway', ''),
(5, 'Británica', 'Booker Prize', 'J.K.', 'Rowling', '');

INSERT INTO editorial VALUES 
(1, 'Planeta', 'Calle 123, Barcelona', '934567890'),
(2, 'Penguin Random House', 'Av. Siempre Viva 742, Springfield', '123456789'),
(3, 'HarperCollins', '345 7th Ave, New York', '987654321'),
(4, 'Anagrama', 'Calle Falsa 123, Madrid', '912345678'),
(5, 'Tusquets', 'Plaza Mayor 1, Salamanca', '654321987');

INSERT INTO premios_autor VALUES 
('Premio Planeta', 1),
('Premio Nobel', 2),
('Premio Akutagawa', 3),
('Pulitzer Prize', 4),
('Booker Prize', 5);

INSERT INTO LIBRO VALUES 
(1, 'La Sombra del Viento', 'Español', '2001-06-06', 1, 1, false, true, true),
(2, 'Cien Años de Soledad', 'Español', '1967-06-05', 2, 2, false, true, true),
(3, 'Kafka en la Orilla', 'Japonés', '2002-09-12', 3, 3, false, true, true),
(4, 'El Viejo y el Mar', 'Inglés', '1952-09-01', 3, 4, false, false, true),
(5, 'Harry Potter y la Piedra Filosofal', 'Inglés', '1997-06-26', 2, 5, true, true, true);

INSERT INTO libr_audiolibro VALUES 
(5, '9783161484100', 400),
(3, '9783161484117', 850),
(1, '9783161484124', 780),
(2, '9783161484131', 900),
(4, '9783161484148', 600);

INSERT INTO libr_digital VALUES 
(1, '9783161484100', 2.5),
(2, '9783161484117', 2.7),
(3, '9783161484124', 1.9),
(5, '9783161484131', 2.3),
(4, '9783161484148', 3.0);

INSERT INTO libr_fisico VALUES 
(1, '9783161484100', 600),
(2, '9783161484117', 417),
(3, '9783161484124', 554),
(4, '9783161484131', 132),
(5, '9783161484148', 223);

INSERT INTO ejemplar VALUES 
(1, '9783161484100', 1, 'Nuevo'),
(2, '9783161484117', 1, 'Usado'),
(3, '9783161484124', 1, 'Nuevo'),
(4, '9783161484131', 1, 'Usado'),
(5, '9783161484148', 1, 'Nuevo');

INSERT INTO usuario VALUES 
(1, 'Ana Pérez', 'Calle Mayor, 10', '611223344', 'ana.perez@example.com', '2024-01-10'), 
(2, 'Luis García', 'Avenida Sol, 23', '622334455', 'luis.garcia@example.com', '2024-02-15'), 
(3, 'Marta López', 'Calle Luna, 35', '633445566', 'marta.lopez@example.com', '2024-03-20'), 
(4, 'Carlos Martínez', 'Calle Mar, 50', '644556677', 'carlos.martinez@example.com', '2024-04-25'), 
(5, 'Laura Sánchez', 'Avenida Norte, 18', '655667788', 'laura.sanchez@example.com', '2024-05-30');

INSERT INTO empleado VALUES 
(1, 'José Ruiz', 'Bibliotecario', '2023-01-10'), 
(2, 'María Fernández', 'Archivista', '2023-02-15'), 
(3, 'Sofía Gómez', 'Catalogadora', '2023-03-20'), 
(4, 'Pedro Díaz', 'Auxiliar', '2023-04-25'), 
(5, 'Lucía Romero', 'Gerente', '2023-05-30');

INSERT INTO prestamo (id, fprestamo, fdevolucion, estado, usuario, empleado) VALUES 
(1, '2025-01-01', '2025-01-15', 'Devuelto', 1, 1), 
(2, '2025-02-01', '2025-02-15', 'Activo', 2, 2), 
(3, '2025-03-01', '2025-03-10', 'Devuelto', 3, 3), 
(4, '2025-04-01', '2025-04-20', 'Vencido', 4, 4), 
(5, '2025-05-01', '2025-05-15', 'Reservado', 5, 5);


INSERT INTO libro_prestamo VALUES 
(1, 1), 
(2, 2), 
(3, 3), 
(4, 4), 
(5, 2);

